import elements.PromotionChooser;
import gui.GameWindow;

public class Main {

    public static void main(String[] args) {

        new GameWindow().show();
        //new PromotionChooser().show(true);

    }


}
